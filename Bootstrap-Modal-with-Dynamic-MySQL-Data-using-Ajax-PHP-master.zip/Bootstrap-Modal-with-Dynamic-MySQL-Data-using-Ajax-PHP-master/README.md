# Bootstrap-Modal-with-Dynamic-MySQL-Data-using-Ajax-PHP
Bootstrap Modal with Dynamic MySQL Data using Ajax &amp; PHP

Uses single modal to display dynamic data from table in mysql database using ajax

HOW TO USE

Import the tbl_members.php

Change the dbconfig.php File to your specifications ie password to your localhost and db name

FINALLY 


OPEN the index.php


ENJOY
